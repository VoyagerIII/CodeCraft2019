##########################
#  -*- coding: utf-8 -*- #
#   v32 for HWCodeCraft  #
#    Author: voyagers    #
#      Date:2019.3       #
#   All Rights Reserved  #
##########################
import logging
import sys
import numpy as np
from itertools import islice
from heapq import heappush, heappop
import math
import copy
import time
import matplotlib.pyplot as plt


logging.basicConfig(level=logging.DEBUG,
                    filename='../logs/CodeCraft-2019.log',
                    format='[%(asctime)s] %(levelname)s [%(funcName)s: %(filename)s, %(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filemode='a')


def read_file(file_path):
    data_list = []
    with open(file_path, 'r') as f:
        for line in islice(f, 1, None):
            line_data = []
            for string in line.strip().strip('(').strip(')').replace(' ','').split(','):
                line_data.append(int(string))
            data_list.append(line_data)
    return data_list


def write_file(file_path, path):
     with open(file_path, 'w') as f:
         for i in range(len(path)):
             path_str = str(path[i][2:]).strip('[').strip(']').replace(' ','')#
             string = '(' + str(path[i][0]) + ',' + str( path[i][1])  + ',' + path_str + ')'  + '\n' # + random.randint(0,400)
             f.write(string)


# 图的结构，邻接表，两级字典
#  graph:{
#          cross_id: {cross_id: [length,channle,isDuplex, Speed],
#           ......
#        }
#  eg:{
#          1： {9: [12, 2, 1], 2:[12, 4, 1]，...}，
#          ......
#     }
# 1-9间的距离：graph[1][2][0] = 12
# 1-9间的车道数：graph[1][2][1] = 2
# 1-9间是否为双向：graph[1][2][3] = 1
def map_build(cross_data, road_data):
    map = {} # 邻接表表示的地图
    # road_data的第一列，保存了所有的道路ID
    # road_id: [5000, 5001, 5002,...]
    road_id = [i[0] for i in road_data]
    for cross_row in cross_data:
        map_in = {} # 内层字典{ 1： {9: [len, channel, isDuplex, speed], 2:[12, 4, 1]，...}，
        for i in range(1, 5):
            dict = {}
            if cross_row[i] == -1:
                continue
            road_row = road_data[road_id.index(cross_row[i])]
            if road_row[6] == 1:
                if road_row[4] == cross_row[0] or road_row[5] == cross_row[0]:
                    if road_row[4] != cross_row[0]:
                        dict = {road_row[4]:[road_row[1],road_row[3],road_row[6],road_row[2]]}
                    else:
                        dict = {road_row[5]:[road_row[1],road_row[3],road_row[6],road_row[2]]}
            if road_row[6] == 0:
                if road_row[4] == cross_row[0]:
                    dict = {road_row[5]:[road_row[1],road_row[3],road_row[6],road_row[2]]}
            map_in.update(dict)
        map.update({cross_row[0]:map_in})
    return map


def map_preset(car_data, preset_data, cross_data):
    preset_map = {}
    preset_time = []
    for presetcar in preset_data:
        preset_map.update({presetcar[0]: presetcar[1:]})
        preset_time.append(presetcar[1])
    preset_time.reverse()
    preset_crossid_map = copy.deepcopy(preset_map)
    for car in car_data:
        if car[6]:
            temp_map = [preset_crossid_map[car[0]][0], car[1]]
            for i in range(1, len(preset_crossid_map[car[0]])-1):
                for cross in cross_data:
                    if (preset_crossid_map[car[0]][i] in cross[1:]) and (preset_crossid_map[car[0]][i+1] in cross[1:]):
                        temp_map.append(cross[0])
            temp_map.append(car[2])
            # print(temp_map)
            preset_crossid_map.update({car[0]: temp_map})

    return preset_map, preset_crossid_map, preset_time


def addtodict2(thedict, key_a, key_b, val):
    if key_a in thedict:
        thedict[key_a].update({key_b: val})
    else:
        thedict.update({key_a: {key_b: val}})


# ------------dijkstar算法的实现-----------start-------------
def init_distance(graph, vertex):
    distance = {start: 0}
    for vertex in graph:
        if vertex != start:
            distance[vertex] = math.inf
    return distance


def dijkstra(graph,start):
    pqueue = []
    heappush(pqueue, (0, start))
    seen = set()
    parent = {start: None}
    distance = init_distance(graph, start)

    while(len(pqueue) > 0):
        pair = heappop(pqueue)
        dist = pair[0]
        vertex = pair[1]
        seen.add(vertex)

        nodes = graph[vertex].keys()
        for w in nodes:
            if w not in seen:
                if dist + graph[vertex][w][0] < distance[w]:
                    heappush(pqueue, (dist + graph[vertex][w][0], w))
                    parent[w] = vertex
                    distance[w] = dist + graph[vertex][w][0]
    return parent, distance

# ------------dijkstar算法的实现-----------end-------------


# 求解最短路径，使用了动态地图，在每一次确定路径时，会将之前经过的road长度进行修改
def path_solve(map, car_data, cross_data, preset_map, preset_crossid_map, choosed_preset_cars):
    road_weight = 42
    preset_precent = 4/3
    path = []  # 最短路径的道路标号
    # map_adjust = copy.deepcopy(map)
    for car_row in car_data:
        if car_row[6] and (car_row[0] not in choosed_preset_cars):
            path_crossId = preset_crossid_map[car_row[0]][1:]
            # 动态修改图的权
            total_length_per_car = 0
            for i in range(len(path_crossId) - 1):
                total_length_per_car += map[path_crossId[i]][path_crossId[i + 1]][0]
            # print(total_length_per_car)
            for i in range(len(path_crossId) - 1):
                # 双向车道与单向车道增加的动态道路权重不同,单向车辆太少，无明显效果
                map[path_crossId[i]][path_crossId[i + 1]][0] += preset_precent*road_weight*map[path_crossId[i]][path_crossId[i + 1]][0] / (
                            map[path_crossId[i]][path_crossId[i + 1]][1] * total_length_per_car)
            path.append(preset_map[car_row[0]][1:])
        else:
            path_crossId = []
            p, d = dijkstra(map, car_row[1])
            distance = d[car_row[2]]
            crossId = car_row[2]
            while crossId != None:
                path_crossId.append(crossId)
                crossId = p[crossId]
            path_crossId.reverse()
            for i in range(len(path_crossId) - 1):
                # 双向车道与单向车道增加的动态道路权重不同,单向车辆太少，无明显效果
                map[path_crossId[i]][path_crossId[i + 1]][0] += road_weight*map[path_crossId[i]][path_crossId[i + 1]][0] / (
                            map[path_crossId[i]][path_crossId[i + 1]][1] * distance)
            path_roadId = []
            # 通过求两个crossId的交集，找到两个crossId直接的roadId
            for i in range(len(path_crossId) - 1):
                for cross_row in cross_data:
                    if cross_row[0] == path_crossId[i]:
                        cross1 = cross_row
                    elif cross_row[0] == path_crossId[i+1]:
                        cross2 = cross_row
                ret1 = [i for i in cross1[1:] if i in cross2[1:]]
                ret2 = [i for i in ret1 if i != -1]
                path_roadId.extend(ret2)
            path.append(path_roadId)

    # 形成输出格式
    path_inlcude_carIdandplanTime = []
    count_unpreset_car = 0
    for i in range(car_data.shape[0]):
        if not car_data[i][6] or (car_data[i][0] in choosed_preset_cars):
            temp = []
            temp.append(car_data[i][0])
            temp.append(car_data[i][4])
            temp.extend(path[i])
            path_inlcude_carIdandplanTime.append(temp)
            count_unpreset_car += 1

    return path_inlcude_carIdandplanTime


def last_car_front(path, car_data, road_data, last_car):
    road_length = {}
    road_speed_limit = {}
    car_speed = {}
    max_end_time = 0
    for road_row in road_data:
        road_length[road_row[0]] = road_row[1]
        road_speed_limit[road_row[0]] = road_row[2]
    for car_row in car_data:
        car_speed[car_row[0]] = car_row[3]
    for path_row in path:
        time_the_car = 0
        for road_per_car in path_row[2:]:
            if car_speed[path_row[0]] < road_speed_limit[road_per_car]:
                time_the_car += road_length[road_per_car] / car_speed[path_row[0]]
            else:
                time_the_car += road_length[road_per_car] / road_speed_limit[road_per_car]
        end_time_the_car = int(time_the_car) + path_row[1]
        path_row.append(end_time_the_car)
        if end_time_the_car > max_end_time:
            max_end_time = end_time_the_car
    print("max_end_time", max_end_time, last_car)
    for path_row in path:
        for i in range(last_car):
            if path_row[-1] == max_end_time - i:
                path_row[1] -= last_car - i
    for path_row in path:
        path_row.pop()
    return path


def change_car_start_time(road_data, path, road_map, max_road_length, min_preset_starttime, max_preset_starttime, choosed_preset_cars):
    road_rate = 1.2  # 可调参数,参考最佳线上拟合值1.15
    dif_rate = 3.5
    road_info = {}        # {5000:[12,4,1],...}
    for row in road_data:
        road_info[row[0]] = [row[1],row[3],row[6]]
    road_cars = {}       # {5000:number, 5001:number,...}
    for row in road_data:
        road_cars[row[0]] = 0

    base_time = 1
    count_cars = 0
    last_start_time = 0
    for row in path:
        count_cars += 1
        base_time_flag = False
        path_length = 0
        for i in range(2, row.__len__()):
            path_length += road_map[row[i]][0]
        for i in range(0,len(row[2:])):
            # print(3.3 / (row.__len__() - 2), road_rate * road_map[row[2+i]][0] / path_length)
            if last_start_time < max_preset_starttime:
                road_cars[row[2 + i]] += dif_rate * road_rate * (2 * max_road_length - road_map[row[2 + i]][0]) / path_length
            else:
                road_cars[row[2+i]] += road_rate * (2*max_road_length-road_map[row[2+i]][0]) / path_length
            if road_info[row[2+i]][2] == 1:
                if road_cars[row[2+i]] > road_info[row[2+i]][0] * road_info[row[2+i]][1] * 2:
                    base_time_flag = True
            else:
                if road_cars[row[2+i]] > road_info[row[2+i]][0] * road_info[row[2+i]][1]:
                    base_time_flag = True
        if base_time_flag:
            for key in road_cars:
                if road_info[key][2] == 1:
                    road_cars[key] -= 2  # road_info[key][1] * 2
                else:
                    road_cars[key] -= 1  # road_info[key][1]
                if road_cars[key] < 0:     # number < 0
                    road_cars[key] = 0
            # 最后n辆车进行冲刺
            # base_time += 1
            if count_cars < path.__len__() * 0.95:
                base_time += 1
        # row[1] += base_time
        if (row[1] < base_time) and (row[0] not in choosed_preset_cars):
            row[1] = base_time
        last_start_time = row[1]
    print('last_start_time', last_start_time)
    print('base_time', base_time)

    return path


def plot_cars_start_per_basetime(answer):
    cars_start_per_basetime = []
    temp_base_time = 0
    # for i in range(answer.__len__()):
    for i in range(1500):
        count_cars_start_per_basetime = 0
        temp_base_time += 1
        for row in answer:
            if row[1] == temp_base_time:
                count_cars_start_per_basetime += 1
        # if count_cars_start_per_basetime == 0:
        #     break
        cars_start_per_basetime.append(count_cars_start_per_basetime)
    # print('cars_start_per_basetime', cars_start_per_basetime)

    preset_time_cars = 0
    free_time_cars = 0
    for i in range(0, 300):
        preset_time_cars += cars_start_per_basetime[i]
    for i in range(500, 800):
        free_time_cars += cars_start_per_basetime[i]
    print(int(preset_time_cars/2), free_time_cars)
    plt.plot(cars_start_per_basetime)
    plt.ylabel('start_cars')
    plt.xlabel('start_time')
    plt.grid(True)
    plt.show()


def main():
    if len(sys.argv) != 6:
        logging.info('please input args: car_path, road_path, cross_path, answerPath')
        exit(1)

    car_path = sys.argv[1]
    road_path = sys.argv[2]
    cross_path = sys.argv[3]
    preset_answer_path = sys.argv[4]
    answer_path = sys.argv[5]

    logging.info("car_path is %s" % (car_path))
    logging.info("road_path is %s" % (road_path))
    logging.info("cross_path is %s" % (cross_path))
    logging.info("preset_answer_path is %s" % (preset_answer_path))
    logging.info("answer_path is %s" % (answer_path))

    # 数据格式调整---------------------------start---------------------
    # 输入的原始数据，除去了原始文件第一行，全部转化成了数字类型的二维列表
    car_data = read_file(car_path) # [ [10000, 19, 59, 6, 3],... ]
    road_data = read_file(road_path) # [ [5000, 12, 4, 4, 1, 2, 1],... ]
    cross_data = read_file(cross_path) # [ [1, 5000, 5007, -1, -1],... ]
    preset_data = read_file(preset_answer_path)

    # car_data_sort:将车辆数据按planTime升序
    #  [[12797  17    62     6     1]
    #          ..........
    #  [16636    23    60     8    10]]
    # priority作为零级排序, plantime作为一级排序, speed作为二级排序, 升序
    car_data_array = np.array(car_data)
    temp = np.ones(car_data_array.shape[0])
    for i in range(car_data_array.shape[0]):
        temp[i] = 1/car_data_array[i, 3] + car_data_array[i, 4]     # *1000
        if car_data_array[i, 5]:
            temp[i] = -1/temp[i]
    car_data_array = np.c_[car_data_array, temp]
    car_data_sort = car_data_array[car_data_array[:, -1].argsort()]
    car_data_sort = car_data_sort.astype(int)

    preset_data = sorted(preset_data, key=(lambda x: [x[1]]))
    preset_car_for_reset = copy.deepcopy(preset_data)
    for row in preset_car_for_reset:
        row.append(len(row))

    preset_car_for_reset = sorted(preset_car_for_reset, key=(lambda x: [-x[-1]]))
    choosed_preset_cars = []
    max_choose_preset = int(0.1*preset_data.__len__())
    count_temp = 0
    for row in preset_car_for_reset:
        count_temp += 1
        if count_temp < max_choose_preset:
            choosed_preset_cars.append(row[0])
        else:
            break
    print(choosed_preset_cars.__len__())
    # priority作为零级降序, plantime作为一级升序, speed作为二级降序,预置车辆为三级降序
    # +:表示升序,-:
    # car_data_sort = sorted(car_data, key=(lambda x: [-x[5], x[4], -x[3], -x[6]]))
    # car_data_sort = np.array(car_data_sort)
    # 数据格式调整---------------------------end---------------------

    # 把输入数据转化为邻接表
    # preset_map = {presetcar_id:[plantime, road1, road2...]}
    # preset_crossid_map = {presetcar_id:[plantime, crossid1, crossid2...]}
    # preset_time = {[palntime1, plantime2...]}  降序
    preset_map, preset_crossid_map, preset_time = map_preset(car_data, preset_data, cross_data)
    map = map_build(cross_data, road_data)
    # road_map {road_id:[length,speed,channel,from,to,isDuplex]}
    road_map = {}
    max_road_length = 0
    for road in road_data:
        road_map[road[0]] = road[1:]
        if road[1] > max_road_length:
            max_road_length = road[1]
    print('max_road_length', max_road_length)
    # car_map {car_id:[from,to,speed,planTime, priority, preset]}
    car_map = {}
    max_priority_plantime = 0
    for car in car_data_sort:
        car_map[car[0]] = car[1:]
        if car[5] and not car[6]:
            if car[4] > max_priority_plantime:
                max_priority_plantime = car[4]
    print('max_priority_plantime', max_priority_plantime)

    max_preset_starttime = 0
    min_preset_starttime = 20000
    preset_time = []
    for perset_car in preset_data:
        if perset_car[1] < min_preset_starttime:
            min_preset_starttime = perset_car[1]
        if perset_car[1] > max_preset_starttime:
            max_preset_starttime = perset_car[1]
        # if perset_car[1] not in preset_time:
            preset_time.append(max_preset_starttime)
    print('max_preset_starttime', max_preset_starttime)
    print('min_preset_starttime', min_preset_starttime)
    # print('preset_time', preset_time)
    # 最短路径的道路标号，car_data：按carId输出。car_data_sort：按planTime输出
    # path:[[10000, 3, 5037, 5050, 5064, 5079, 5092],...]
    path = path_solve(map, car_data_sort, cross_data, preset_map, preset_crossid_map, choosed_preset_cars)
    answer = change_car_start_time(road_data, path, road_map, max_road_length, min_preset_starttime, max_preset_starttime, choosed_preset_cars)
    answer = last_car_front(answer, car_data, road_data, 100)

    # answer.extend(preset_data)
    # plot_cars_start_per_basetime(answer)

#  to write output file
    write_file(answer_path, answer)


if __name__ == "__main__":
    start = time.clock()
    main()
    elapsed = (time.clock() - start)
    print("Time used:", elapsed)
