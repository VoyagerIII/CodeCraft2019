##########################
#  -*- coding: utf-8 -*- #
#   v12 for HWCodeCraft  #
#    Author: voyagers    #
#      Date:2019.3       #
#   All Rights Reserved  #
##########################
import logging
import sys
import numpy as np
from itertools import islice
from heapq import heappush, heappop
import math
import copy
import time


logging.basicConfig(level=logging.DEBUG,
                    filename='../logs/CodeCraft-2019.log',
                    format='[%(asctime)s] %(levelname)s [%(funcName)s: %(filename)s, %(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filemode='a')

def read_file(file_path):
    data_list = []
    with open(file_path, 'r') as f:
        for line in islice(f, 1, None):
            line_data = []
            for string in line.strip().strip('(').strip(')').replace(' ','').split(','):
                line_data.append(int(string))
            data_list.append(line_data)
    return data_list

def write_file(file_path, path):
     with open(file_path, 'w') as f:
         for i in range(len(path)):
             path_str = str(path[i][2:]).strip('[').strip(']').replace(' ','')#
             string = '(' + str(path[i][0]) + ',' + str( path[i][1])  + ',' + path_str + ')'  + '\n' # + random.randint(0,400)
             f.write(string)

# 图的结构，邻接表，两级字典
#  graph:{
#          cross_id: {cross_id: [length,channle,isDuplex],
#           ......
#        }
#  eg:{
#          1： {9: [12, 2, 1], 2:[12, 4, 1]，...}，
#          ......
#     }
# 1-9间的距离：graph[1][2][0] = 12
# 1-9间的车道数：graph[1][2][1] = 2
# 1-9间是否为双向：graph[1][2][3] = 1
def map_build(cross_data, road_data):
    map = {} # 邻接表表示的地图
    # road_data的第一列，保存了所有的道路ID
    # road_id: [5000, 5001, 5002,...]
    road_id = [i[0] for i in road_data]
    for cross_row in cross_data:
        map_in = {} # 内层字典{ 1： {9: [12, 2, 1], 2:[12, 4, 1]，...}，
        for i in range(1,5):
            dict = {}
            if cross_row[i] == -1:
                continue
            road_row = road_data[road_id.index(cross_row[i])]
            if road_row[6] == 1:
                if road_row[4] == cross_row[0] or road_row[5] == cross_row[0]:
                    if road_row[4] != cross_row[0]:
                        dict = {road_row[4]:[road_row[1],road_row[3],road_row[6]]}
                    else:
                        dict = {road_row[5]:[road_row[1],road_row[3],road_row[6]]}
            if road_row[6] == 0:
                if road_row[4] == cross_row[0]:
                    dict = {road_row[5]:[road_row[1],road_row[3],road_row[6]]}
            map_in.update(dict)
        map.update({cross_row[0]:map_in})
    return map


def addtodict2(thedict, key_a, key_b, val):
    if key_a in thedict:
        thedict[key_a].update({key_b: val})
    else:
        thedict.update({key_a: {key_b: val}})

# ------------dijkstar算法的实现-----------start-------------
def init_distance(graph, vertex):
    distance = {start: 0}
    for vertex in graph:
        if vertex != start:
            distance[vertex] = math.inf
    return distance

def dijkstra(graph,start):
    pqueue = []
    heappush(pqueue, (0, start))
    seen = set()
    parent = {start: None}
    distance = init_distance(graph, start)

    while(len(pqueue) > 0):
        pair = heappop(pqueue)
        dist = pair[0]
        vertex = pair[1]
        seen.add(vertex)

        nodes = graph[vertex].keys()
        for w in nodes:
            if w not in seen:
                if dist + graph[vertex][w][0] < distance[w]:
                    heappush(pqueue, (dist + graph[vertex][w][0], w))
                    parent[w] = vertex
                    distance[w] = dist + graph[vertex][w][0]
    return parent, distance

# def dijkstra(vs, ve, graph):
#     inf = float('inf')
#     # G = copy.deepcopy(graph)
#     lists1 = copy.deepcopy(graph[vs])  # 获取起点到其他各顶点的初始路程
#     path = [ve]  # A是记录起点到终点的路径上的节点
#     # v = min(lists1, key=lists1.get)  # 得到离起点最近的点（就是lists1的键）
#     lists3 = {}  # 记录每一次迭代后某一点由最短路程到达的下一节点，最后用于总结路径
#     lists2 = {}  # 记录每一次迭代之后各顶点离起点的最短路程，最后用于总结长度
#     for key, value in list(lists1.items()):
#         if value != inf:
#             lists3[key] = vs
#     #######START****START#########
#     while ve not in lists2:
#         v = min(lists1, key=lists1.get)  # 找到离起点最近的点
#         lists2[v] = lists1[v]
#         del lists1[v]
#         for key, value in list(lists1.items()):
#             if value > lists2[v] + graph[v][key]:
#                 lists1[key] = lists2[v] + graph[v][key]
#                 lists3[key] = v
#     length = lists2[ve]
#     while vs not in path:
#         for k in list(lists3.keys()):
#             if k == ve:
#                 path.append(lists3[k])
#                 ve = lists3[k]
#                 del lists3[k]
#     path.reverse()
#     #########END****END###########
#     return path, length

# ------------dijkstar算法的实现-----------end-------------


# 求解最短路径，使用了动态地图，在每一次确定路径时，会将之前经过的road长度进行修改
def path_solve(map, car_data, cross_data):
    path = []  # 最短路径的道路标号
    for car_row in car_data:
        path_crossId = []
        p, d = dijkstra(map, car_row[1])
        distance = d[car_row[2]]
        crossId = car_row[2]
        while crossId != None:
            path_crossId.append(crossId)
            crossId = p[crossId]
        path_crossId.reverse()

        # 动态修改图的权
        total_length_per_car = 0
        for i in range(len(path_crossId) - 1):
            total_length_per_car += map[path_crossId[i]][path_crossId[i + 1]][0]
        # print(total_length_per_car)
        for i in range(len(path_crossId) - 1):
            # 双向车道与单向车道增加的动态道路权重不同,单向车辆太少，无明显效果
            # if map[path_crossId[i]][path_crossId[i + 1]][2] == 1:
            map[path_crossId[i]][path_crossId[i + 1]][0] += 12.01*map[path_crossId[i]][path_crossId[i + 1]][0] / (
                        map[path_crossId[i]][path_crossId[i + 1]][1] * total_length_per_car)
            # print(10*map[path_crossId[i]][path_crossId[i + 1]][0] / (
            #             map[path_crossId[i]][path_crossId[i + 1]][1] * total_length_per_car))
            # else:
            #     map[path_crossId[i]][path_crossId[i + 1]][0] += map[path_crossId[i]][path_crossId[i + 1]][0] / (
            #                 map[path_crossId[i]][path_crossId[i + 1]][1] * total_length_per_car)

        path_roadId = []
        # 通过求两个crossId的交集，找到两个crossId直接的roadId
        for i in range(len(path_crossId) - 1):
            for cross_row in cross_data:
                if cross_row[0] == path_crossId[i]:
                    cross1 = cross_row
                elif cross_row[0] == path_crossId[i+1]:
                    cross2 = cross_row
            ret1 = [i for i in cross1[1:] if i in cross2[1:]]
            ret2 = [i for i in ret1 if i != -1]
            path_roadId.extend(ret2)
        path.append(path_roadId)

    # 形成输出格式
    path_inlcude_carIdandplanTime = []
    for i in range(len(path)):
        temp = []
        temp.append(car_data[i][0])
        temp.append(car_data[i][4])
        temp.extend(path[i])
        path_inlcude_carIdandplanTime.append(temp)

    return path_inlcude_carIdandplanTime


def last_car_front(path, car_data, road_data, last_car):
    road_length = {}
    road_speed_limit = {}
    car_speed = {}
    max_end_time = 0
    for road_row in road_data:
        road_length[road_row[0]] = road_row[1]
        road_speed_limit[road_row[0]] = road_row[2]
    for car_row in car_data:
        car_speed[car_row[0]] = car_row[3]
    for path_row in path:
        time_the_car = 0
        for road_per_car in path_row[2:]:
            if car_speed[path_row[0]] < road_speed_limit[road_per_car]:
                time_the_car += road_length[road_per_car] / car_speed[path_row[0]]
            else:
                time_the_car += road_length[road_per_car] / road_speed_limit[road_per_car]
        end_time_the_car = int(time_the_car) + path_row[1]
        path_row.append(end_time_the_car)
        if end_time_the_car > max_end_time:
            max_end_time = end_time_the_car
    print("max_end_time", max_end_time, last_car)
    for path_row in path:
        for i in range(last_car):
            if path_row[-1] == max_end_time - i:
                path_row[1] -= last_car - i
    for path_row in path:
        path_row.pop()
    return path


def change_car_start_time(road_data, path):
    road_info = {}        # {5000:[12,4,1],...}
    for row in road_data:
        road_info[row[0]] = [row[1],row[3],row[6]]
    road_cars = {}       # {5000:number, 5001:number,...}
    for row in road_data:
        road_cars[row[0]] = 0

    base_time = 0
    count_cars = 0
    last_start_time = 0
    for row in path:
        count_cars += 1
        base_time_flag = False
        for i in range(0,len(row[2:])):
            road_cars[row[2+i]] += 2.1/(row.__len__()-2)  # 可调参数,参考最佳线上拟合值2.2
            if road_info[row[2+i]][2] == 1:
                if road_cars[row[2+i]] > road_info[row[2+i]][0] * road_info[row[2+i]][1] * 2:
                    base_time_flag = True
            else:
                if road_cars[row[2+i]] > road_info[row[2+i]][0] * road_info[row[2+i]][1]:
                    base_time_flag = True

        if base_time_flag:
            for key in road_cars:
                if road_info[key][2] == 1:
                    road_cars[key] -= 2  # road_info[key][1] * 2
                else:
                    road_cars[key] -= 1  # road_info[key][1]
                if road_cars[key] < 0:     # number < 0
                    road_cars[key] = 0
            # base_time += 1
            # 最后n辆车进行冲刺
            # if (count_cars > path.__len__()*0.05)  and (count_cars < path.__len__()*0.88):  # 可调参数,参考最佳线上拟合值0.05,0.85
            if count_cars < path.__len__()*0.93:
                base_time += 1
        # row[1] += int(base_time)
        if count_cars < path.__len__()*0.93:
            row[1] += int(base_time)
            last_start_time = row[1]
        else:
            row[1] = last_start_time
    print(last_start_time)
    print(base_time)
    return path



def main():
    if len(sys.argv) != 5:
        logging.info('please input args: car_path, road_path, cross_path, answerPath')
        exit(1)

    car_path = sys.argv[1]
    road_path = sys.argv[2]
    cross_path = sys.argv[3]
    answer_path = sys.argv[4]

    logging.info("car_path is %s" % (car_path))
    logging.info("road_path is %s" % (road_path))
    logging.info("cross_path is %s" % (cross_path))
    logging.info("answer_path is %s" % (answer_path))

# 数据格式调整---------------------------start---------------------
    # 输入的原始数据，除去了原始文件第一行，全部转化成了数字类型的二维列表
    car_data = read_file(car_path) # [ [10000, 19, 59, 6, 3],... ]
    road_data = read_file(road_path) # [ [5000, 12, 4, 4, 1, 2, 1],... ]
    cross_data = read_file(cross_path) # [ [1, 5000, 5007, -1, -1],... ]

    # car_data_sort:将车辆数据按planTime升序
    #  [[12797  17    62     6     1]
    #          ..........
    #  [16636    23    60     8    10]]
    # plantime作为一级排序，speed作为二级排序，升序
    car_data_array = np.array(car_data)
    temp = np.ones(car_data_array.shape[0])
    for i in range(car_data_array.shape[0]):
        temp[i] = 1/car_data_array[i, -2] + car_data_array[i, -1]
    car_data_array = np.c_[car_data_array,temp]
    car_data_sort = car_data_array[car_data_array[:, -1].argsort()]
    car_data_sort = car_data_sort.astype(int)
# 数据格式调整---------------------------end---------------------

    # 把输入数据转化为邻接表
    map = map_build(cross_data, road_data)

    # 最短路径的道路标号，car_data：按carId输出。car_data_sort：按planTime输出
    # path:[[10000, 3, 5037, 5050, 5064, 5079, 5092],...]
    path = path_solve(map, car_data_sort, cross_data)
    answer = change_car_start_time(road_data, path)
    answer = last_car_front(answer, car_data, road_data, 30)

#  to write output file
    write_file(answer_path, answer)


if __name__ == "__main__":
    start = time.clock()
    main()
    elapsed = (time.clock() - start)
    print("Time used:", elapsed)
